#ifndef CONFIG_H_INCLUDED
#define CONFIG_H_INCLUDED

typedef int Elem_t;
#define POISON_VALUE 666
#define ELEM_T_SPECIFIER "%d"

#define CANARY_PROTECTION
#define HASH_PROTECTION

#endif // CONFIG_H_INCLUDED
